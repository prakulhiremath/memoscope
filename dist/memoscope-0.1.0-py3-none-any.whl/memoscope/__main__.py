"""memoscope.__main__ — allows `python -m memoscope` entry point."""
from memoscope.cli import main
main()
